# Kódovna · Lokální AI

Statická webová aplikace. Soubory aplikace jsou v kořeni tohoto ZIPu.

## Spuštění

Nahraj obsah ZIPu do kořene GitHub repozitáře. V repozitáři otevři **Settings → Pages** a nastav **Source: GitHub Actions**. Workflow v `.github/workflows/deploy.yml` web nasadí po každém pushi do větve `main`.

AI vyžaduje prohlížeč s WebGPU. Knihovna WebLLM a zvolený model se načítají při prvním spuštění; odpovědi se generují v prohlížeči. Dostupné funkce a kvalitu omezuje výkon zvoleného lokálního modelu.
